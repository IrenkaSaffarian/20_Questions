import java.util.Scanner;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

public class Main {

  public static void main(String[] args) throws UnsupportedEncodingException {
    System.out.println("\n \n Lets play 20 questions. Type all answers without abbreviation, properly spelled, and in lowercase.");
    Scanner scan = new Scanner(System.in);
    System.out.println("First question. Is your first name Benjamin?");

    String answer= scan.nextLine();

    if (answer.equals("yes"))
    {
      System.out.println("Good. \n Next question. What is your favorite color?");

        answer= scan.nextLine();
        if(answer.equals("black")|| answer.equals("red"))
        {
          System.out.println("Red and black are both good colors. \n So what's your opinion on brownies (yes/no)?");
                    
          answer= scan.nextLine();
          if(answer.equals("yes"))
          {
            System.out.println("Good choice. \n Fourth question: what is the airspeed velocity of an unladen swallow?");
            
            answer= scan.nextLine();
            if(answer.indexOf("african") != -1){
              System.out.println("I don't know... I guess I lose. Congratulations!");
            }
            else{
              System.out.println("If you don't know, it's GAME OVER. Also, question five: Is the object you're thinking of a vegetable?");
            }

          }
          else{
            System.out.println("GAME OVER");
          }

        }
        else if (answer.equals("green")||answer.equals("blue")){
          System.out.println("Green is lame, and blue is too. \n What does that mean? \n GAME OVER for you!");
        }
        else {
          System.out.println("Sorry Benjamin. Pick red or black next time... \n GAME OVER.");
        }
    }
    else{
      PrintStream eye = new PrintStream(System.out, true, "UTF-8");

      System.out.println("GAME OVER. How sad..");
      eye.print("\u0CA0");
      System.out.print("_");
      eye.print("\u0CA0");
    }
  }
}